import requests

BACKEND_URL = "http://localhost:8000/api/search"

def search_query(query, top_k):
    if not query:
        return []
    payload = {"query": query, "top_k": top_k}
    try:
        res = requests.post(BACKEND_URL, json=payload)
        if res.status_code == 200:
            return res.json().get("results", [])
    except Exception as e:
        print(e)
    return []