import streamlit as st
from utils.api_client import search_query

st.set_page_config(page_title="Semantic Search Engine", layout="wide")

st.title("Semantic Search Engine Demo")
query = st.text_input("Enter your search query:")
top_k = st.slider("Number of results", 1, 10, 5)

if st.button("Search"):
    with st.spinner("Searching..."):
        results = search_query(query, top_k)
        for r in results:
            st.write(f"**Score**: {r['score']:.2f} | {r['document']}")