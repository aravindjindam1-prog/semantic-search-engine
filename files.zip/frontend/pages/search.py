import streamlit as st
from utils.api_client import search_query

st.write("## Search")
query = st.text_input("Query:")
top_k = st.number_input("Number of results:", 1, 10, 5)

if st.button("Run Search"):
    results = search_query(query, int(top_k))
    for res in results:
        st.markdown(f"- **{res['score']:.2f}**: {res['document']}")