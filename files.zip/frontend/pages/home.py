import streamlit as st

st.write("# Welcome to Semantic Search Engine!")
st.write("Explore hybrid search (semantic + keyword) capabilities through an easy web interface.")