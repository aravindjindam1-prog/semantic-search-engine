from fastapi import FastAPI
from app.api.routes import api_router

app = FastAPI(title="Semantic Search Engine", version="1.0.0")

app.include_router(api_router, prefix="/api")

@app.get("/")
def read_root():
    return {"message": "Semantic Search Engine Backend Running"}