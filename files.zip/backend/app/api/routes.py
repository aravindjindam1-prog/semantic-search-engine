from fastapi import APIRouter
from .models import SearchRequest, SearchResponse
from app.services.hybrid_retrieval import hybrid_search

api_router = APIRouter()

@api_router.post("/search", response_model=SearchResponse)
def search_api(request: SearchRequest):
    results = hybrid_search(request.query, request.top_k)
    return SearchResponse(results=results)