import pandas as pd
from app.core.config import DATASET_PATH
from app.services.embedding_model import embed_text
from app.utils.preprocessing import preprocess
from sklearn.metrics.pairwise import cosine_similarity

# Dummy in-memory vector index
data = pd.read_csv(DATASET_PATH)
documents = data["text"].tolist()
document_vectors = [embed_text(preprocess(doc)) for doc in documents]

def hybrid_search(query: str, top_k: int = 5):
    query_vec = embed_text(preprocess(query))
    scores = cosine_similarity([query_vec], document_vectors)[0]
    results = sorted(zip(documents, scores), key=lambda x: x[1], reverse=True)[:top_k]
    return [{"document": doc, "score": float(score)} for doc, score in results]