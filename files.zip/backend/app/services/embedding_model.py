from sentence_transformers import SentenceTransformer
from app.core.config import EMBEDDING_MODEL_NAME

model = SentenceTransformer(EMBEDDING_MODEL_NAME)

def embed_text(text: str):
    return model.encode(text)