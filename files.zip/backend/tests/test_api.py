import pytest
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_search_api():
    response = client.post("/api/search", json={"query": "semantic search", "top_k": 2})
    assert response.status_code == 200
    data = response.json()
    assert "results" in data
    assert isinstance(data["results"], list)