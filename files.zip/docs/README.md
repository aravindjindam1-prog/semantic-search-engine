# Semantic Search Engine

This project is a minimal hybrid search system combining semantic (vector-based) search and traditional keyword search.

## Features
- **Backend:** FastAPI, in-memory vector index, Pydantic models.
- **Frontend:** Streamlit app for searching and browsing results.
- **Hybrid retrieval:** Combines semantic similarity and keyword matching.

## Project Structure

See the directory layout for backend, frontend, and documentation.

## How to Run

1. Install backend dependencies: `pip install -r backend/requirements.txt`
2. Start backend: `uvicorn backend.main:app --reload`
3. Install frontend dependencies: `pip install streamlit requests`
4. Start frontend: `streamlit run frontend/app.py`
5. Explore at [localhost:8501](http://localhost:8501)