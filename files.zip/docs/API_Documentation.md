# API Documentation

## Overview

Base URL: `/api`

### POST `/api/search`

#### Request Body

```json
{
  "query": "search query",
  "top_k": 5
}
```

#### Response

```json
{
  "results": [
    { "document": "...", "score": 0.88 },
    ...
  ]
}
```