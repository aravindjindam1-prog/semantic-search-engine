#!/bin/bash

echo "Starting backend (FastAPI)…"
uvicorn backend.main:app --reload &
BACKEND_PID=$!

echo "Waiting for backend to boot up…"
sleep 5

echo "Starting frontend (Streamlit)…"
streamlit run frontend/app.py

kill $BACKEND_PID